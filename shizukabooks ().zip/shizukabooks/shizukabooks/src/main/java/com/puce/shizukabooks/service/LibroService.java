package com.puce.shizukabooks.service;

import com.puce.shizukabooks.models.Libro;
import com.puce.shizukabooks.repository.LibroRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LibroService {

    private final LibroRepository libroRepository;

    public LibroService(LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }

    // LISTAR TODOS
    public List<Libro> traerTodos() {
        return libroRepository.findAll();
    }

    // TRAER UNO POR ID
    public Optional<Libro> traerUno(int id) {
        return libroRepository.findById(id);
    }

    // GUARDAR / CREAR
    public Libro guardar(Libro libro) {
        return libroRepository.save(libro);
    }

    // EDITAR
    public Optional<Libro> editar(int id, Libro libroDetalles) {
        return libroRepository.findById(id).map(libroExistente -> {
            libroExistente.setTitulo(libroDetalles.getTitulo());
            libroExistente.setAutor(libroDetalles.getAutor());
            libroExistente.setAnio(libroDetalles.getAnio());
            libroExistente.setDisponible(libroDetalles.isDisponible());
            return libroRepository.save(libroExistente);
        });
    }

    // ELIMINAR
    public boolean eliminar(int id) {
        if (libroRepository.existsById(id)) {
            libroRepository.deleteById(id);
            return true;
        }
        return false;
    }
}