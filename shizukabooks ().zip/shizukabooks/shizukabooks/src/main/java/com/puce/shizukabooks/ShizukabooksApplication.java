package com.puce.shizukabooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShizukabooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShizukabooksApplication.class, args);
	}

}
