package com.puce.shizukabooks.repository;

import com.puce.shizukabooks.models.Libro;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LibroRepository extends JpaRepository<Libro, Integer> {

    List<Libro> findByAutorContainingIgnoreCase(String texto);
}