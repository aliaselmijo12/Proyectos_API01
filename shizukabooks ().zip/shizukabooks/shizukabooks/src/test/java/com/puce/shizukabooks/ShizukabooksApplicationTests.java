package com.puce.shizukabooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShizukabooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
